const chalk = require('chalk');
const PaymentController = require('../controllers/paymentController');

function processPayment(order) {
    if (!order) {
        console.log(chalk.bgRed.white("\n❌ Erro ao processar pagamento. Pedido não encontrado.\n"));
        return;
    }

    console.clear();
    console.log(chalk.blue.bold(`💳 Processando Pagamento | Saldo: R$${PaymentController.getBalance().toFixed(2)}\n`));

    console.log(chalk.yellow(` Pedido #${order.id} - Total: R$${order.total.toFixed(2)} `));

    const status = PaymentController.processPayment(order);

    console.log(chalk.blue.bold(`💰 Saldo Atualizado: R$${PaymentController.getBalance().toFixed(2)}\n`));

    if (status === "Pago") {
        console.log(chalk.bgGreen.black('\n ✅ Pagamento Aprovado! \n'));
    } else {
        console.log(chalk.bgRed.white('\n ❌ Pagamento Recusado! \n'));
        console.log(chalk.bgRed.white("\n❌ Erro ao processar pagamento. Tente novamente.\n"));
    }
}

module.exports = { processPayment };