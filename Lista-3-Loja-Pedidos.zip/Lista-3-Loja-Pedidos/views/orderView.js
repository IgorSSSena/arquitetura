const readlineSync = require('readline-sync');
const OrderController = require('../controllers/OrderController');
const CatalogView = require('..//views/catalogView');
const PaymentController = require('../controllers/PaymentController');
const chalk = require('chalk');
const Table = require('cli-table3');

function createOrder(username) {
    console.clear();
    console.log(chalk.blue.bold('\n🛒 Criar um Novo Pedido\n'));

    CatalogView.showProducts();

    let productId = readlineSync.questionInt(chalk.green('\n📥 Digite o ID do produto desejado: '));
    let quantity = readlineSync.questionInt(chalk.green('🔢 Quantidade: '));

    const cart = [{ productId, quantity }];
    const order = OrderController.createOrder(username, cart);

    if (!order) {
        console.log(chalk.bgRed.white('\n❌ Pedido falhou. Estoque insuficiente.\n'));
        return createOrder(username);
    }

    console.clear();
    console.log(chalk.blue.bold('\n📜 Resumo do Pedido\n'));

    const orderTable = new Table({
        head: [chalk.yellow('Produto'), chalk.yellow('Qtd'), chalk.yellow('Preço Unitário (R$)'), chalk.yellow('Total')],
        colWidths: [30, 10, 20, 15],
        style: { head: ['cyan'] }
    });

    order.items.forEach(item => {
        const product = CatalogView.getProductsByCategory("Ver Todos").find(p => p.id === item.productId);
        const totalItem = product.price * item.quantity;
        orderTable.push([product.name, item.quantity, `R$${product.price.toFixed(2)}`, `R$${totalItem.toFixed(2)}`]);
    });

    console.log(orderTable.toString());
    console.log(chalk.green.bold(`\n💰 Total do Pedido: R$${order.total.toFixed(2)}\n`));

    const paymentStatus = PaymentController.processPayment(order);
    if (paymentStatus === "Saldo Insuficiente") {
        return createOrder(username);
    }
}

module.exports = { createOrder };